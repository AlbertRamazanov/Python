import contriller
import user_interface as ui

ui.start()
contriller.user_choice()